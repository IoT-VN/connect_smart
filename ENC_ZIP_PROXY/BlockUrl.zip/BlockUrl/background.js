chrome.webRequest.onBeforeRequest.addListener(
  info => {
    const host = (info.initiator || '').split('/', 3)[2];
	console.log(host);
    if (host === 'connect.appen.com' || host === 'identity.appen.com' || host === 'c.connect.appen.com') {
      return {cancel: true};
    }
  },
  {
    urls: [
      '*://*.recaptcha.net/*',
      '*://*.gstatic.com/*',
	  '*://*.connect.facebook.net/*',
	  '*://*.d35fpyi7wmbdba.cloudfront.net/*',
	  '*://*.googleads.g.doubleclick.net/*',
	  '*://*.facebook.com/*',
	  '*://*.googleadservices.com/*',
	  '*://*.googletagmanager.com/*',
	  '*://*.optimizationguide-pa.googleapis.com/*',
	  '*://*.cdn.mxpnl.com/*',
	  '*://*/*.png',
	  '*://*/*.svg',
	  '*://*.google-analytics.com/*',
	  '*://*.cookie-cdn.cookiepro.com/*',
	  '*://*/*.woff2',
	  '*://*/*.woff',
	  '*://*/*.otf',
	  '*://*/*.ttf',
	  '*://*/*.ico',
	  '*://*.connect.appen.com/matomo/matomo.php*',
	  '*://*.connect.appen.com/matomo/matomo.js',
    ],
  },
  ['blocking']
);